/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.009569377990430622, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Loads my account page"], "isController": false}, {"data": [0.0, 500, 1500, "Submits authentiction page"], "isController": false}, {"data": [0.0, 500, 1500, "Submits address to step 2"], "isController": false}, {"data": [0.0, 500, 1500, "Submits sign on form-0"], "isController": false}, {"data": [0.0, 500, 1500, "Submits sign on form-1"], "isController": false}, {"data": [0.0, 500, 1500, "Logout-1"], "isController": false}, {"data": [0.0, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.0, 500, 1500, "Submits authentication"], "isController": false}, {"data": [0.0, 500, 1500, "Submits payment as check-1"], "isController": false}, {"data": [0.0, 500, 1500, "Submits payment as check-0"], "isController": false}, {"data": [0.0, 500, 1500, "Loads order step 1-1"], "isController": false}, {"data": [0.0, 500, 1500, "Loads order step 1-0"], "isController": false}, {"data": [0.0, 500, 1500, "Logout"], "isController": false}, {"data": [0.0, 500, 1500, "Submits shipping page to order step 3"], "isController": false}, {"data": [0.0, 500, 1500, "Add product to cart"], "isController": false}, {"data": [0.2222222222222222, 500, 1500, "Loads my account page-0"], "isController": false}, {"data": [0.0, 500, 1500, "Loads order page"], "isController": false}, {"data": [0.0, 500, 1500, "Loads order step 1"], "isController": false}, {"data": [0.0, 500, 1500, "Loads my account page-1"], "isController": false}, {"data": [0.0, 500, 1500, "Submits shipping page to order step 3-1"], "isController": false}, {"data": [0.0, 500, 1500, "Submits payment as check"], "isController": false}, {"data": [0.0, 500, 1500, "Submits shipping page to order step 3-0"], "isController": false}, {"data": [0.0, 500, 1500, "Loads authentication page-0"], "isController": false}, {"data": [0.0, 500, 1500, "Loads check payment page"], "isController": false}, {"data": [0.0, 500, 1500, "Loads authentication page"], "isController": false}, {"data": [0.0, 500, 1500, "Loads authentication page-1"], "isController": false}, {"data": [0.0, 500, 1500, "Submits authentication-1"], "isController": false}, {"data": [0.0, 500, 1500, "Submits authentication-0"], "isController": false}, {"data": [0.0, 500, 1500, "Submits sign on form"], "isController": false}, {"data": [0.0, 500, 1500, "Loads home index page"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 209, 0, 0.0, 4368.17703349282, 596, 11510, 7305.0, 8380.0, 10804.800000000001, 1.711851912523548, 51.52893741297403, 1.935823790339094], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["Loads my account page", 19, 0, 0.0, 4051.684210526316, 1988, 7431, 6054.0, 7431.0, 7431.0, 0.15793323580263333, 4.828782708804362, 0.1805484699178747], "isController": false}, {"data": ["Submits authentiction page", 10, 0, 0.0, 3269.7999999999997, 1831, 4309, 4278.0, 4309.0, 4309.0, 0.09092644959492267, 0.4781452595495504, 0.09797680125296647], "isController": false}, {"data": ["Submits address to step 2", 5, 0, 0.0, 4482.2, 2990, 6195, 6195.0, 6195.0, 6195.0, 0.18376272556874562, 5.820110073872616, 0.2118296106067845], "isController": false}, {"data": ["Submits sign on form-0", 6, 0, 0.0, 2574.3333333333335, 2040, 3134, 3134.0, 3134.0, 3134.0, 0.054300116745251, 0.022024070789252198, 0.07696051702761161], "isController": false}, {"data": ["Submits sign on form-1", 6, 0, 0.0, 3198.5, 1904, 4317, 4317.0, 4317.0, 4317.0, 0.054031662554256794, 1.4526109956684616, 0.057215168713866324], "isController": false}, {"data": ["Logout-1", 7, 0, 0.0, 4323.0, 2014, 5412, 5412.0, 5412.0, 5412.0, 0.06947959781238523, 5.583017185654448, 0.039411836593911606], "isController": false}, {"data": ["Logout-0", 7, 0, 0.0, 2478.714285714286, 1590, 3139, 3139.0, 3139.0, 3139.0, 0.06872919714479278, 0.03784516477825015, 0.05189207797818339], "isController": false}, {"data": ["Submits authentication", 5, 0, 0.0, 9102.0, 7082, 10713, 10713.0, 10713.0, 10713.0, 0.1441462219275233, 4.8274907566235195, 0.3433608052007957], "isController": false}, {"data": ["Submits payment as check-1", 5, 0, 0.0, 3646.8, 2633, 4450, 4450.0, 4450.0, 4450.0, 0.22735540196435067, 6.290550967397235, 0.2686079739223354], "isController": false}, {"data": ["Submits payment as check-0", 5, 0, 0.0, 3814.6, 3519, 4732, 4732.0, 4732.0, 4732.0, 0.2283000776220264, 0.09029446429386787, 0.2639273748915575], "isController": false}, {"data": ["Loads order step 1-1", 5, 0, 0.0, 5647.0, 4716, 6797, 6797.0, 6797.0, 6797.0, 0.15469339768578677, 5.698729532129819, 0.12928379857372685], "isController": false}, {"data": ["Loads order step 1-0", 5, 0, 0.0, 4302.8, 3345, 5129, 5129.0, 5129.0, 5129.0, 0.16156654926164088, 0.08662112846156332, 0.11136100631725208], "isController": false}, {"data": ["Logout", 7, 0, 0.0, 6802.285714285715, 3804, 8552, 8552.0, 8552.0, 8552.0, 0.06739647420159248, 5.45273957641316, 0.08911604108296506], "isController": false}, {"data": ["Submits shipping page to order step 3", 5, 0, 0.0, 8103.0, 6480, 10815, 10815.0, 10815.0, 10815.0, 0.1705262439889499, 5.543734919085297, 0.38071982324954806], "isController": false}, {"data": ["Add product to cart", 6, 0, 0.0, 3544.5, 2148, 5140, 5140.0, 5140.0, 5140.0, 0.06279632013564006, 0.08542507221576816, 0.05394514610610485], "isController": false}, {"data": ["Loads my account page-0", 9, 0, 0.0, 1684.4444444444443, 596, 2868, 2868.0, 2868.0, 2868.0, 0.316622691292876, 0.10265501319261214, 0.21121921723834652], "isController": false}, {"data": ["Loads order page", 5, 0, 0.0, 5717.2, 4366, 6831, 6831.0, 6831.0, 6831.0, 0.16052395017336585, 5.531335529167202, 0.10688010666816489], "isController": false}, {"data": ["Loads order step 1", 5, 0, 0.0, 9950.2, 8061, 11510, 11510.0, 11510.0, 11510.0, 0.1401856057420024, 5.23943701460734, 0.21378304875655366], "isController": false}, {"data": ["Loads my account page-1", 9, 0, 0.0, 2967.777777777778, 2023, 4984, 4984.0, 4984.0, 4984.0, 0.2829032156665514, 9.71844376709207, 0.19425038506271022], "isController": false}, {"data": ["Submits shipping page to order step 3-1", 5, 0, 0.0, 4115.8, 2986, 4846, 4846.0, 4846.0, 4846.0, 0.21516481624924694, 6.761092082472675, 0.23025156801359842], "isController": false}, {"data": ["Submits payment as check", 5, 0, 0.0, 7461.4, 6232, 8453, 8453.0, 8453.0, 8453.0, 0.19538118869915205, 5.483151730588879, 0.4567035285842679], "isController": false}, {"data": ["Submits shipping page to order step 3-0", 5, 0, 0.0, 3986.4, 2595, 6082, 6082.0, 6082.0, 6082.0, 0.20429843915992482, 0.22201494443082453, 0.2374969355234126], "isController": false}, {"data": ["Loads authentication page-0", 5, 0, 0.0, 2738.6, 2505, 3174, 3174.0, 3174.0, 3174.0, 0.23313283909171445, 0.07171566827528326, 0.22275114235091156], "isController": false}, {"data": ["Loads check payment page", 5, 0, 0.0, 4065.6, 2836, 5003, 5003.0, 5003.0, 5003.0, 0.22005105184402782, 6.402969864008449, 0.22409105162397674], "isController": false}, {"data": ["Loads authentication page", 10, 0, 0.0, 4680.0, 1958, 7047, 7024.8, 7047.0, 7047.0, 0.09212938651041522, 2.8357677084197044, 0.1179148183208498], "isController": false}, {"data": ["Loads authentication page-1", 5, 0, 0.0, 3738.8, 3489, 4251, 4251.0, 4251.0, 4251.0, 0.22382380589999554, 6.0176691408523215, 0.20948509333452708], "isController": false}, {"data": ["Submits authentication-1", 5, 0, 0.0, 5422.6, 3744, 7212, 7212.0, 7212.0, 7212.0, 0.16167103178452485, 5.155253449655641, 0.200257360073722], "isController": false}, {"data": ["Submits authentication-0", 5, 0, 0.0, 3678.6, 3337, 4395, 4395.0, 4395.0, 4395.0, 0.16159265722965546, 0.25902166755542627, 0.18475847957468813], "isController": false}, {"data": ["Submits sign on form", 10, 0, 0.0, 4884.0, 2570, 7034, 6989.6, 7034.0, 7034.0, 0.08842749387639605, 3.195712634409791, 0.1730553688752907], "isController": false}, {"data": ["Loads home index page", 18, 0, 0.0, 3597.7222222222226, 1555, 4699, 4599.1, 4699.0, 4699.0, 0.1480384900074019, 11.886698831626779, 0.10164795624640184], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 209, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
